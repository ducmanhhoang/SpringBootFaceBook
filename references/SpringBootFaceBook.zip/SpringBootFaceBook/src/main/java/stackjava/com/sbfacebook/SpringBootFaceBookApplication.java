package stackjava.com.sbfacebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFaceBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFaceBookApplication.class, args);
	}
}
